const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const { imageOverlay } = require('../utils/imageOverlay');

// Configure multer for file upload
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function(req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Upload face image
router.post('/upload-face', upload.single('face'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    // Update user's face image in database
    const userId = req.user.id; // Assuming auth middleware sets this
    await User.findByIdAndUpdate(userId, { faceImage: req.file.path });

    res.json({ 
      message: 'Face image uploaded successfully',
      imagePath: req.file.path 
    });
  } catch (error) {
    res.status(500).json({ message: 'Error uploading face image', error: error.message });
  }
});

// Generate try-on image
router.post('/generate', async (req, res) => {
  try {
    const { clothingId } = req.body;
    const userId = req.user.id; // Assuming auth middleware sets this

    // Get user's face image and clothing image
    const user = await User.findById(userId);
    const clothing = await Clothing.findById(clothingId);

    if (!user.faceImage || !clothing.imageUrl) {
      return res.status(400).json({ message: 'Missing required images' });
    }

    // Generate try-on image using overlay
    const resultImage = await imageOverlay(user.faceImage, clothing.imageUrl);

    res.json({
      message: 'Try-on image generated successfully',
      resultImage
    });
  } catch (error) {
    res.status(500).json({ message: 'Error generating try-on image', error: error.message });
  }
});

module.exports = router;
