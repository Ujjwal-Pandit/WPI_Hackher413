const express = require('express');
const router = express.Router();
const Clothing = require('../models/Clothing');

// Get all clothes
router.get('/', async (req, res) => {
  try {
    const { category, size, color, brand } = req.query;
    
    // Build filter object based on query parameters
    const filter = {};
    if (category) filter.category = category;
    if (size) filter.size = size;
    if (color) filter.color = color;
    if (brand) filter.brand = brand;

    const clothes = await Clothing.find(filter);
    res.json(clothes);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching clothes', error: error.message });
  }
});

// Get clothing by ID
router.get('/:id', async (req, res) => {
  try {
    const clothing = await Clothing.findById(req.params.id);
    if (!clothing) {
      return res.status(404).json({ message: 'Clothing not found' });
    }
    res.json(clothing);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching clothing', error: error.message });
  }
});

// Search clothes by query
router.get('/search/:query', async (req, res) => {
  try {
    const searchQuery = req.params.query;
    const clothes = await Clothing.find({
      $or: [
        { title: { $regex: searchQuery, $options: 'i' } },
        { description: { $regex: searchQuery, $options: 'i' } },
        { brand: { $regex: searchQuery, $options: 'i' } },
        { tags: { $in: [new RegExp(searchQuery, 'i')] } }
      ]
    });
    res.json(clothes);
  } catch (error) {
    res.status(500).json({ message: 'Error searching clothes', error: error.message });
  }
});

// Add new clothing (admin only)
router.post('/', async (req, res) => {
  try {
    const clothing = new Clothing(req.body);
    await clothing.save();
    res.status(201).json(clothing);
  } catch (error) {
    res.status(500).json({ message: 'Error adding clothing', error: error.message });
  }
});

// Update clothing (admin only)
router.put('/:id', async (req, res) => {
  try {
    const clothing = await Clothing.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!clothing) {
      return res.status(404).json({ message: 'Clothing not found' });
    }
    res.json(clothing);
  } catch (error) {
    res.status(500).json({ message: 'Error updating clothing', error: error.message });
  }
});

// Delete clothing (admin only)
router.delete('/:id', async (req, res) => {
  try {
    const clothing = await Clothing.findByIdAndDelete(req.params.id);
    if (!clothing) {
      return res.status(404).json({ message: 'Clothing not found' });
    }
    res.json({ message: 'Clothing deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting clothing', error: error.message });
  }
});

module.exports = router;
