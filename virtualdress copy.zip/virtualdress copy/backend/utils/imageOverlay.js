const Jimp = require('jimp');

async function imageOverlay(faceImagePath, clothingImagePath) {
  try {
    // Load both images
    const faceImage = await Jimp.read(faceImagePath);
    const clothingImage = await Jimp.read(clothingImagePath);

    // Resize clothing image to match face image width while maintaining aspect ratio
    clothingImage.resize(faceImage.getWidth(), Jimp.AUTO);

    // Create a new image with combined height
    const finalHeight = faceImage.getHeight() + clothingImage.getHeight();
    const finalImage = new Jimp(faceImage.getWidth(), finalHeight, 0x0);

    // Composite face image at the top
    finalImage.composite(faceImage, 0, 0);

    // Composite clothing image below the face
    finalImage.composite(clothingImage, 0, faceImage.getHeight());

    // Generate unique filename
    const outputPath = `uploads/tryon_${Date.now()}.jpg`;

    // Save the final image
    await finalImage.writeAsync(outputPath);

    return outputPath;
  } catch (error) {
    console.error('Error in image overlay:', error);
    throw error;
  }
}

module.exports = {
  imageOverlay
};
