import React, { useState, useEffect } from 'react';
import API from '../services/api';

const containerStyle = {
  maxWidth: '800px',
  margin: '0 auto',
  padding: '20px'
};

const chatContainerStyle = {
  border: '1px solid #ddd',
  borderRadius: '4px',
  padding: '20px',
  marginBottom: '20px',
  maxHeight: '400px',
  overflowY: 'auto'
};

const messageStyle = {
  margin: '10px 0',
  padding: '10px',
  borderRadius: '4px'
};

const inputContainerStyle = {
  display: 'flex',
  gap: '10px',
  marginBottom: '20px'
};

const inputStyle = {
  flex: 1,
  padding: '8px',
  border: '1px solid #ddd',
  borderRadius: '4px'
};

const buttonStyle = {
  padding: '8px 16px',
  backgroundColor: '#28a745',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer'
};

const clothingGridStyle = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
  gap: '20px',
  marginTop: '20px'
};

const clothingItemStyle = {
  border: '1px solid #ddd',
  padding: '10px',
  borderRadius: '4px',
  textAlign: 'center'
};

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [recommendations, setRecommendations] = useState([]);

  useEffect(() => {
    // Initial greeting
    setMessages([
      {
        sender: 'bot',
        text: 'Welcome! I can help you find the perfect outfit. What kind of clothes are you looking for today?'
      }
    ]);
  }, []);

  const handleSend = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage = { sender: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');

    try {
      // Get clothing recommendations based on user input
      const { data } = await API.get(`/clothes/search/${input}`);
      setRecommendations(data);

      // Add bot response
      const botMessage = {
        sender: 'bot',
        text: `I found ${data.length} items that match your description. Here are some recommendations:`
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error getting recommendations:', error);
      setMessages(prev => [...prev, {
        sender: 'bot',
        text: 'Sorry, I had trouble finding recommendations. Please try again.'
      }]);
    }
  };

  const handleTryOn = async (item) => {
    try {
      const { data } = await API.post('/tryon/generate', { clothingId: item._id });
      
      setMessages(prev => [...prev, {
        sender: 'bot',
        text: 'Here\'s how it would look on you:',
        image: data.resultImage
      }]);
    } catch (error) {
      console.error('Error generating try-on:', error);
      setMessages(prev => [...prev, {
        sender: 'bot',
        text: 'Sorry, I couldn\'t generate the try-on image. Please try again.'
      }]);
    }
  };

  return (
    <div style={containerStyle}>
      <div style={chatContainerStyle}>
        {messages.map((msg, i) => (
          <div
            key={i}
            style={{
              ...messageStyle,
              backgroundColor: msg.sender === 'user' ? '#e3f2fd' : '#f5f5f5'
            }}
          >
            <b>{msg.sender === 'user' ? 'You:' : 'Bot:'}</b>
            {msg.text && <span style={{ marginLeft: '8px' }}>{msg.text}</span>}
            {msg.image && (
              <div style={{ marginTop: '10px' }}>
                <img
                  src={msg.image}
                  alt="Try-On"
                  style={{
                    maxWidth: '200px',
                    borderRadius: '4px',
                    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                  }}
                />
              </div>
            )}
          </div>
        ))}
      </div>

      <div style={inputContainerStyle}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          style={inputStyle}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
        />
        <button onClick={handleSend} style={buttonStyle}>
          Send
        </button>
      </div>

      {recommendations.length > 0 && (
        <div style={clothingGridStyle}>
          {recommendations.map((item) => (
            <div key={item._id} style={clothingItemStyle}>
              <p style={{ margin: '0 0 10px 0' }}>{item.title}</p>
              <img
                src={item.imageUrl}
                alt={item.title}
                style={{
                  width: '100%',
                  maxWidth: '150px',
                  height: 'auto',
                  borderRadius: '4px',
                  marginBottom: '10px'
                }}
              />
              <button
                onClick={() => handleTryOn(item)}
                style={{
                  ...buttonStyle,
                  width: '100%',
                  backgroundColor: '#17a2b8'
                }}
              >
                Try On
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
