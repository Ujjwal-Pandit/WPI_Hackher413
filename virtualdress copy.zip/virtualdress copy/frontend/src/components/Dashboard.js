import React from 'react';
import { Link } from 'react-router-dom';

const containerStyle = {
  maxWidth: '1200px',
  margin: '0 auto',
  padding: '20px'
};

const headerStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: '30px'
};

const buttonStyle = {
  padding: '10px 20px',
  backgroundColor: '#007bff',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  textDecoration: 'none',
  cursor: 'pointer'
};

const cardContainerStyle = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
  gap: '20px',
  marginTop: '20px'
};

const cardStyle = {
  border: '1px solid #ddd',
  borderRadius: '8px',
  padding: '20px',
  textAlign: 'center'
};

export default function Dashboard() {
  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    window.location.href = '/login';
  };

  return (
    <div style={containerStyle}>
      <header style={headerStyle}>
        <h1>Virtual Dress Room</h1>
        <button onClick={handleLogout} style={{...buttonStyle, backgroundColor: '#dc3545'}}>
          Logout
        </button>
      </header>

      <div style={cardContainerStyle}>
        <Link to="/try-on" style={{ textDecoration: 'none' }}>
          <div style={cardStyle}>
            <h2>Virtual Try-On</h2>
            <p>Try on clothes virtually using your measurements</p>
          </div>
        </Link>
        
        <Link to="/wardrobe" style={{ textDecoration: 'none' }}>
          <div style={cardStyle}>
            <h2>My Wardrobe</h2>
            <p>View and manage your virtual wardrobe</p>
          </div>
        </Link>
        
        <Link to="/profile" style={{ textDecoration: 'none' }}>
          <div style={cardStyle}>
            <h2>Profile</h2>
            <p>Update your measurements and preferences</p>
          </div>
        </Link>
        
        <Link to="/chat" style={{ textDecoration: 'none' }}>
          <div style={cardStyle}>
            <h2>Style Assistant</h2>
            <p>Chat with our AI style assistant</p>
          </div>
        </Link>
      </div>
    </div>
  );
}
