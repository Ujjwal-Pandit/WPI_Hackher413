import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import API from '../services/api';

const inputStyle = {
  width: '100%',
  padding: '8px',
  margin: '10px 0',
  border: '1px solid #ddd',
  borderRadius: '4px',
  boxSizing: 'border-box'
};

const buttonStyle = {
  width: '100%',
  padding: '10px',
  backgroundColor: '#007bff',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
  marginTop: '10px'
};

export default function Register() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    height: '',
    weight: '',
    bust: '',
    waist: '',
    hips: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { data } = await API.post('/auth/register', {
        ...formData,
        measurements: {
          height: parseFloat(formData.height),
          weight: parseFloat(formData.weight),
          bust: parseFloat(formData.bust),
          waist: parseFloat(formData.waist),
          hips: parseFloat(formData.hips)
        }
      });

      localStorage.setItem('token', data.token);
      localStorage.setItem('userId', data.userId);
      navigate('/chat');
    } catch (error) {
      console.error('Registration error:', error);
      alert(error.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <div style={{ maxWidth: '400px', margin: '0 auto', padding: '20px' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Register</h2>
      
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Full Name"
          value={formData.name}
          onChange={handleChange}
          style={inputStyle}
          required
        />
        
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
          style={inputStyle}
          required
        />
        
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          style={inputStyle}
          required
        />

        <h3 style={{ marginTop: '20px' }}>Body Measurements</h3>
        
        <input
          type="number"
          name="height"
          placeholder="Height (cm)"
          value={formData.height}
          onChange={handleChange}
          style={inputStyle}
        />
        
        <input
          type="number"
          name="weight"
          placeholder="Weight (kg)"
          value={formData.weight}
          onChange={handleChange}
          style={inputStyle}
        />
        
        <input
          type="number"
          name="bust"
          placeholder="Bust (cm)"
          value={formData.bust}
          onChange={handleChange}
          style={inputStyle}
        />
        
        <input
          type="number"
          name="waist"
          placeholder="Waist (cm)"
          value={formData.waist}
          onChange={handleChange}
          style={inputStyle}
        />
        
        <input
          type="number"
          name="hips"
          placeholder="Hips (cm)"
          value={formData.hips}
          onChange={handleChange}
          style={inputStyle}
        />

        <button type="submit" style={buttonStyle}>
          Register
        </button>
      </form>

      <p style={{ textAlign: 'center', marginTop: '20px' }}>
        Already have an account? <Link to="/login">Login</Link>
      </p>
    </div>
  );
}
