import pdfminer.high_level
import os
import re
import PyPDF2
import io
import base64
import pdfplumber
import pdfminer.high_level
import requests
from google.cloud import firestore
from anthropic import Anthropic
from dotenv import load_dotenv
import firebase_admin
from firebase_admin import credentials, firestore
from concurrent.futures import ThreadPoolExecutor
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import logging
from typing import List, Dict, Any
import random
from google.generativeai import generative_models
import google.generativeai as genai

class JobApplicationProcessor:
    load_dotenv()
    def __init__(self):
            print("var init")
    def generate_interview_questions(self, resume_concise, job_desc):
        try:
            # Create the Gemini model
            model = genai.GenerativeModel('gemini-pro')

            # Construct the prompt
            prompt = f""":
                    {resume_concise}

                    Job Description:
                    {job_desc}

                    For each question, provide:
                    1. The interview question
                    2. A potential answer highlighting relevant skills or experiences
                    3. What the interviewer is looking to assess with the question"""

            # Generate the content
            response = model.generate_content(prompt)

            # Return the generated interview questions
            return {
                "interview_questions": response.text
            }

        except Exception as e:
            # Log the error and raise an exception
            logging.error(f"Error generating interview questions: {str(e)}")
            raise Exception(f"API call failed: {str(e)}")


    def generate_coverletter(self, resume_concise, job_desc, company, job_position):
        TOKEN_LIMIT = 1400
        EARLY_CLOSE_THRESHOLD = int(TOKEN_LIMIT * 0.1)  # 70% of the token limit
        WORD_LIMIT = 3000

        def ensure_closing_phrase(content, token_count, threshold, closing_phrases_check):
            if token_count >= threshold:
                last_lines = "\n".join(content.strip().split("\n")[-2:])
                normalized_last_lines = last_lines.replace("\n[Your Name]", "").strip()
                if not any(phrase in normalized_last_lines for phrase in closing_phrases_check):
                    content = get_fallback_cover_letter(job_position, company)
            return content

        def get_fallback_cover_letter(job_position, company):
            templates = [
                f"Dear Hiring Manager,\n\nI am excited to apply for the {job_position} position at {company}. With my skills and experiences, I am eager to contribute to your team and support the mission of {company}.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nPlease accept this letter as my application for the {job_position} role at {company}. My background in [relevant field] makes me a strong candidate for this position.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI am writing to express my interest in the {job_position} position at {company}. My passion for [industry] and my expertise in [skill] align perfectly with the role.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI was thrilled to discover the opening for a {job_position} at {company}. I am confident my skills and experience will make me an asset to your team.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nWith a strong background in [relevant field], I am excited to apply for the {job_position} role at {company}. I am eager to bring my expertise to your organization.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI am reaching out to express my interest in the {job_position} position at {company}. My experience in [specific field or expertise] equips me to contribute effectively to your team.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nIt is with great enthusiasm that I apply for the {job_position} position at {company}. My unique combination of skills in [skill] and experience in [field] make me a great fit for this role.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI am excited about the opportunity to join {company} as a {job_position}. My background in [specific area] aligns well with the responsibilities outlined for this position.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nThe {job_position} role at {company} caught my attention immediately. My career has been focused on achieving success in [specific field], and I am eager to bring this drive to your team.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nAs an experienced professional in [field], I am eager to apply for the {job_position} position at {company}. I believe my expertise in [specific skill] will enable me to make a significant impact.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nMy enthusiasm for [industry or field] has drawn me to apply for the {job_position} position at {company}. With a solid foundation in [specific skill or experience], I am ready to contribute meaningfully to your team.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nJoining {company} as a {job_position} presents an exciting opportunity to leverage my skills in [specific area]. I am eager to collaborate with your team to achieve exceptional results.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI am writing to apply for the {job_position} position at {company}. My expertise in [specific area] and passion for [related field] make me an ideal candidate for this role.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nThe chance to contribute to {company} as a {job_position} is one I am truly excited about. My experience in [specific area] ensures that I can bring immediate value to your team.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nApplying for the {job_position} role at {company} is a step I am excited to take. My track record in [specific field] demonstrates my ability to excel in positions like this.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nIt is with great excitement that I submit my application for the {job_position} position at {company}. My professional experience in [specific area] aligns closely with your requirements.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nMy background in [specific field] makes me a strong contender for the {job_position} role at {company}. I am eager to bring my skills and expertise to your team.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI am enthusiastic about the opportunity to join {company} as a {job_position}. With a proven record in [specific area], I am confident in my ability to excel in this role.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI am drawn to the {job_position} position at {company} because of your reputation for excellence in [specific area]. My skills in [related skill] align perfectly with the job requirements.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nMy career in [specific field] has prepared me well for the {job_position} position at {company}. I am eager to bring my expertise to your organization and contribute to your success.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI am excited to bring my skills in [specific area] to the {job_position} position at {company}. My background uniquely positions me to make a positive impact on your team.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nThe {job_position} role at {company} is an ideal match for my skills and experiences in [specific area]. I look forward to contributing to your organization’s success.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nJoining {company} as a {job_position} represents an exciting opportunity for me to apply my experience in [specific area]. I am confident in my ability to add value to your team.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI am thrilled at the prospect of contributing to {company} as a {job_position}. My background in [specific skill or area] equips me well for this opportunity.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nIt is with great enthusiasm that I apply for the {job_position} position at {company}. My passion for [industry] and expertise in [skill] align with your team’s goals.\n\nBest regards,\n[Your Name]",
                f"Dear Hiring Manager,\n\nI am eager to bring my skills in [specific area] to the {job_position} role at {company}. This opportunity aligns perfectly with my career aspirations and abilities.\n\nBest regards,\n[Your Name]",
            ]
            return random.choice(templates)

        # Adjust the prompt to explicitly instruct for an early close based on token usage
        prompt = (
            'generate coverletter'
        )

        try:
            # Validation checks
            if not company:
                raise ValueError("Company name is required")
            if not resume_concise:
                raise ValueError("Resume content is required")
            if not job_desc:
                raise ValueError("Job description is required")
            if not job_position:
                raise ValueError("Job position is required")

            # API Call
            response = self.anthropic.messages.create(
                model="claude-3-5-haiku-20241022",
                max_tokens=TOKEN_LIMIT,
                temperature=0.3,
                system="You are an expert AI",
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

            og_content = response.content[0].text.strip()
            token_count = len(og_content.split())
            # Enforce early closing if content nears 70% token usage
            closing_phrases_check = [
                "Best regards,",
                "Sincerely,",
                "Kind regards,",
                "Yours truly,",
                "Warm regards,",
                "Respectfully,",
                "Thank you,",
                "With gratitude,",
                "Cordially,",
                "Yours faithfully,",
                "With best wishes,",
                "Thank you for your consideration,",
                "Looking forward to hearing from you,",
                "With kind regards,",
                "Yours respectfully,"
            ]
            content = ensure_closing_phrase(og_content, token_count, EARLY_CLOSE_THRESHOLD, closing_phrases_check)

            # If no content or content is incomplete, use fallback
            if not content or len(content.split()) < 50:  # Minimum 50 words
                content = get_fallback_cover_letter(job_position, company)

            # Trim to word limit if necessary
            words = content.split()
            if len(words) > WORD_LIMIT:
                content = ' '.join(words[:WORD_LIMIT]) + "..."

            return {
                "cover_letter": content,
            }

        except Exception as e:
            # Fallback on error
            fallback_content = get_fallback_cover_letter(job_position, company)
            return {
                "cover_letter": fallback_content,
                "note": f"Used fallback template due to error: {str(e)}"
            }

    def generate_email_body(self, resume_consice, job_desc, company, email_type, JOBPOSITION):
        temperature = 0.4 if email_type == "short" else 0.5
        if email_type == "short":
            prompt = (
                 "approximately 260 words. Use the information from the resume, job description, and company name to tailor the content effectively."
            )
        else:
            prompt = (
                f"You are tasked with creating a 300-word job application email based on the following inputs:"
                                        )

        try:
            if not company:
                raise ValueError("Company name is required")
            if not resume_consice:
                raise ValueError("Resume content is required")
            if not job_desc:
                raise ValueError("Job description is required")

            response = self.anthropic.messages.create(
                model="claude-3-5-haiku-20241022",
                max_tokens=400,
                temperature=temperature,
                system="You are an expert at writing compelling ai",
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

            # Validate response
            if not response or not response.content:
                raise ValueError("no company found please try dding domain eg : abc.com,abc.co.in")

            content = response.content[0].text.strip()

            # More robust subject line extraction
            lines = content.split('\n')
            email_parts = {'subject': '', 'body': []}
            found_subject = False

            for line in lines:
                line = line.strip()
                if line.lower().startswith('subject:'):
                    email_parts['subject'] = line.replace('SUBJECT:', '', 1).replace('Subject:', '', 1).strip()
                    found_subject = True
                elif found_subject:
                    email_parts['body'].append(line)

            if not email_parts['subject']:
                # If no subject line found, attempt to generate one
                fallback_subject = f"Application for Position at {company}"
                email_parts['subject'] = fallback_subject
                print(f"Warning: No subject line found, using fallback: {fallback_subject}")

            # Join body lines with proper spacing
            body = '\n'.join(line for line in email_parts['body'] if line)
            logging.info(f"Extracted text using decoding {body}")

            # Ensure we have content
            if not body:
                raise ValueError("No email body content generated")

            result_key = "concise" if email_type == "short" else "detailed"
            return {result_key: {"subject": email_parts['subject'], "body": body}}

        except Exception as e:
            error_message = f"Error generating email body: {str(e)}"
            print(error_message)
            return {'error': error_message}


    def extract_text_from_pdf(self, pdf_content: bytes) -> str:
        """
        Extract text content from a PDF binary content with multiple fallback methods
        """


        extraction_methods = [
            # Method 1: PyPDF2 (primary method)
            lambda content: {
                'method': 'PyPDF2',
                'text': sanitize_text(''.join(
                    page.extract_text() or '' for page in PyPDF2.PdfReader(io.BytesIO(content)).pages
                ))
            },

            # Method 2: pdfplumber
            lambda content: {
                'method': 'pdfplumber',
                'text': sanitize_text('\n'.join(
                    page.extract_text() or '' for page in pdfplumber.open(io.BytesIO(content)).pages
                ))
            },

            # Method 3: pdfminer
            lambda content: {
                'method': 'pdfminer',
                'text': sanitize_text(
                    pdfminer.high_level.extract_text(io.BytesIO(content))
                )
            }
        ]

        # Attempt text extraction with multiple methods
        for method in extraction_methods:
            try:
                result = method(pdf_content)
                if result['text']:
                    logging.info(f"Successfully extracted text using {result['method']}")
                    return result['text']
            except Exception as e:
                logging.warning(f"Text extraction failed with {method.__name__}: {str(e)}")

        # Fallback: attempt raw text conversion
        try:
            # Try decoding with different encodings
            encodings = ['utf-8', 'latin-1', 'ascii', 'utf-16']
            for encoding in encodings:
                try:
                    text = pdf_content.decode(encoding, errors='ignore')
                    sanitized_text = sanitize_text(text)
                    if sanitized_text:
                        logging.info(f"Extracted text using {encoding} decoding")
                        return sanitized_text
                except Exception:
                    continue
        except Exception as e:
            logging.error(f"All text extraction methods failed: {str(e)}")

        # Absolute last resort
        logging.error("Could not extract any meaningful text from PDF")
        return "Unable to extract text from PDF"


    def get_resume_data_by_email_for_coverletter(self, email):
        """
        Get user data from Firestore database
        Returns a dictionary with user data or error message
        """
        try:
            if not self.db:
                raise ValueError("Database connection not initialized")

            users_ref = self.db.collection('user')
            query = users_ref.where('email', '==', email).limit(1)
            results = list(query.stream())

            if not results:
                logging.warning(f"No user found with email: {email}")
                return {
                    'error': f"No user found with the email: {email}",
                    'status': 'not_found'
                }

            user_data = results[0].to_dict()

            # Add the email to the user data
            user_data['email'] = email

            # Validate required fields
            required_fields = ['company', 'jobDescription', 'jobPosition']
            missing_fields = [field for field in required_fields if not user_data.get(field)]

            if missing_fields:
                logging.error(f"Missing required fields for user {email}: {missing_fields}")
                return {
                    'error': f"Missing required fields: {', '.join(missing_fields)}",
                    'status': 'invalid_data'
                }

            # Return structured data with all required fields
            return {
                'status': 'success',
                'userEmail': email,

            }

        except Exception as e:
            logging.error(f"Error retrieving user data for {email}: {str(e)}")
            return {
                'error': f"Error retrieving user data: {str(e)}",
                'status': 'error'
            }

    def get_resume_data_by_email(self, email):
        """
        Get user data from Firestore database
        Returns a dictionary with user data or error message
        """
        try:

            if not results:
                logging.warning(f"No user found with email: {email}")
                return {
                    'error': f"No user found with the email: {email}",
                    'status': 'not_found'
                }

            user_data = results[0].to_dict()

            # Add the email to the user data
            user_data['email'] = email

            # Validate required fields
            required_fields = ['company', 'jobDescription', '', 'jobPosition']
            missing_fields = [field for field in required_fields if not user_data.get(field)]

            if missing_fields:
                logging.error(f"Missing required fields for user {email}: {missing_fields}")
                return {
                    'error': f"Missing required fields: {', '.join(missing_fields)}",
                    'status': 'invalid_data'
                }

            # Return structured data with all required fields
            return {
                'status': 'success',
                'userEmail': email,

            }

        except Exception as e:
            logging.error(f"Error retrieving user data for {email}: {str(e)}")
            return {
                'error': f"Error retrieving user data: {str(e)}",
                'status': 'error'
            }

    # def get_only_resume_data_by_email(self, email: str) -> Dict[str, Any]:
    def get_only_resume_data_by_email(self, email):
        """
        Get and process resume data from Firestore
        """
        try:
            if not self.db:
                raise ValueError("Database connection not initialized")
            
            users_ref = self.db.collection('user')
            query = users_ref.where('email', '==', email).limit(1)
            results = query.stream()
            user_data = next((doc.to_dict() for doc in results), None)
            if not user_data:
                return {'error': f"No user found with the email: {email}"}
            resumes = user_data.get('resumes', [])
            # logging.error(f"{resumes}")
            if not resumes:
                return {'error': "No resumes found for the user."}
            # resume_data = resumes[0]
            decoded_resume = base64.b64decode(resumes[0].get("fileContent", ""))
            # Extract text from the PDF
            resume_text = self.extract_text_from_pdf(decoded_resume)
            return {
                "resume": {
                    "fileContent": resume_text,
                }
            }
        except Exception as e:
            logging.error(f"Error in get_resume_data_by_email: {email}, {str(e)}")
            return {'error': f"Error retrieving user data: {e}"}

    def extract_names_from_email(self, email):
        """Extract first and last names from the email prefix."""
        prefix = email.split('@')[0]
        name_parts = prefix.split('.')
        if len(name_parts) == 2:
            return name_parts[0].capitalize(), name_parts[1].capitalize()
        elif len(name_parts) == 1:
            return name_parts[0].capitalize(), ""
        else:
            return "N/A", "N/A"



    def generate_coverletter_output(self, jobPosition, company, resume_concise, job_desc_no_stop_wd):

        try:
            # Generate cover letter
            tailored_cover_letter = self.generate_coverletter(
                resume_concise,
                job_desc_no_stop_wd,
                company,
                jobPosition
            )

            # Check if cover letter generation was successful
            if not tailored_cover_letter:
                logging.error("Cover letter generation failed")
                return {'error': "Failed to generate cover letter"}

            # Check if there was an error in the cover letter generation
            if 'error' in tailored_cover_letter:
                logging.error(f"Error in cover letter generation: {tailored_cover_letter['error']}")
                return tailored_cover_letter

            return {
                "cover_letter": tailored_cover_letter.get('cover_letter')
            }

        except Exception as e:
            logging.error(f"Error in generate_output: {str(e)}")
            return {'error': f"Error generating output: {str(e)}"}

##############################
    def match_resumes_with_skills(self, required_skills: List[str], top_n: int = 5) -> List[Dict[str, Any]]:
        """
        Match resumes against required skills and return top matches with downloadable resume data
        Processing resumes in parallel for better performance
        """
        try:
            # Get all users from the database
            users_ref = self.db.collection('user')
            all_users = [user.to_dict() for user in users_ref.stream()]

            if not all_users:
                return []

            # Process resumes in parallel
            with ThreadPoolExecutor(max_workers=min(len(all_users), 10)) as executor:
                # Use list comprehension to execute process_single_resume for each user
                all_resumes = list(filter(None, executor.map(
                    lambda user: self.process_single_resume(user),
                    all_users
                )))

            if not all_resumes:
                return []

            # Initialize TF-IDF vectorizer
            vectorizer = TfidfVectorizer(stop_words='english')

            # Convert required skills to a single string
            required_skills_text = ' '.join(required_skills)

            # Prepare all texts for comparison
            resume_texts = [resume['resume_text'] for resume in all_resumes]
            resume_texts.append(required_skills_text)

            # Calculate TF-IDF vectors
            tfidf_matrix = vectorizer.fit_transform(resume_texts)

            # Calculate similarity scores
            similarity_scores = cosine_similarity(
                tfidf_matrix[-1:],  # Required skills vector
                tfidf_matrix[:-1]  # Resume vectors
            )[0]

            # Create list of (index, score) tuples and sort by score
            scored_resumes = list(enumerate(similarity_scores))
            scored_resumes.sort(key=lambda x: x[1], reverse=True)

            # Get top N matches
            top_matches = []
            for idx, score in scored_resumes[:top_n]:
                resume = all_resumes[idx]
                # Extract skills from resume text
                found_skills = [skill for skill in required_skills
                                if skill.lower() in resume['resume_text'].lower()]

                match_info = {
                    'userData': resume['userData'],
                    'match_score': round(score * 100, 2),
                    'matched_skills': found_skills,
                    'resumeFile': {
                        'fileContent': resume['fileContent'],
                        'fileName': resume['fileName'],
                        'fileType': resume['fileType']
                    }
                }
                top_matches.append(match_info)

            return top_matches

        except Exception as e:
            logging.error(f"Error in matching resumes: {str(e)}")
            return []


    def process_single_resume(self, user_data: Dict) -> Dict:
        """
        Process a single user's resume data
        """
        try:
            resumes = user_data.get('resumes', [])
            if not resumes:
                return None

            resume_data = resumes[0]
            decoded_resume = base64.b64decode(resume_data.get("fileContent", ""))
            resume_text = self.extract_text_from_pdf(decoded_resume)

            return {
                'email': user_data.get('email'),
                'resume_text': resume_text,
                'fileContent': resume_data.get("fileContent"),
                'fileName': resume_data.get("fileName", "resume.pdf"),
                'fileType': resume_data.get("fileType", "application/pdf"),
                'userData': {
                    'name': user_data.get('name', ''),
                    'phone': user_data.get('phone', ''),
                    'email': user_data.get('email', '')
                }
            }
        except Exception as e:
            logging.error(f"Error processing resume for {user_data.get('email')}: {str(e)}")
            return None
